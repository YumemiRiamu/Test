#include<stdio.h>
struct st {
	char n[80];
	int kor;
};
int main() {
	struct st we[2] = {
	{"Shim", 88},
	{"Park", 85}
	};

	FILE* f = fopen("my.bin", "wb");
	fwrite(we, sizeof(we), 2, f);
	fclose(f);
}